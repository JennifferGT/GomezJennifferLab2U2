//ESTE ES EL CONTROLADOR DE LA VISTA DEL TAB1 
import { Component } from '@angular/core';
import {UsuarioServiceService} from '../usuario-service.service'; //importando servicio

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
  //variables para almacenar datos, any para que sea objeto typescript
  private usuario:any;
  private cedula: string;
  private nombre: string;
  private apellido: string;
  private direccion: string;
  private telefono: string;
  private correo: string;

  constructor(public usuarioService: UsuarioServiceService) {}

  //funcion asincrona
  async getUsuarioByCedula(){
    try{

      this.usuario=await this.usuarioService.getUserByCedula(this.cedula);
      //SACANDO LOS DATOS
      this.nombre=this.usuario[0].nombreusuario;//despues del punto es lo del arreglo en el servidor 
      this.apellido=this.usuario[0].apellidousuario;
      this.direccion=this.usuario[0].direccionusuario;
      this.telefono=this.usuario[0].telefonousuario;
      this.correo=this.usuario[0].correousuario;
    }catch(error){
      console.log(error); //si hay error
    }
  }

}
