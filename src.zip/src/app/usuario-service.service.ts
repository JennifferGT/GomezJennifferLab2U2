import { Injectable } from '@angular/core';
//importando librerias
import {HttpClient,HttpHeaders} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class UsuarioServiceService {

  //URL DE TODOS LOS WEB SERVICES
  url="http://localhost:3000/";

  constructor(public http: HttpClient,public https:HttpClient) {}

   //consumo de web services
    getUserByCedula(cedula: string){
        return new Promise(resolve=>{  //la promesa es en la espera
          this.http.get(this.url+'usuario/'+cedula).subscribe(data=>{
            resolve(data);
          },err=>{
            console.log(err);
          });
          });
        };
    }

